<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
ensureSessionStarted();

function loadCustomerRequest(string $mobile, int $requestId): ?array
{
    $stmt = getPdo()->prepare('SELECT * FROM portal_service_requests_staging WHERE id = ? AND mobile = ? LIMIT 1');
    $stmt->execute([$requestId, $mobile]);
    $row = $stmt->fetch();
    return $row ?: null;
}

try {
    $mobile = requireCustomerLogin();
    $requestId = (int)($_GET['request_id'] ?? $_POST['request_id'] ?? 0);
    if ($requestId <= 0) {
        flash('ابتدا درخواست پذیرش را ثبت کنید.', 'bad');
        redirect('customer-service-request.php');
    }

    $request = loadCustomerRequest($mobile, $requestId);
    if (!is_array($request)) {
        flash('پرونده پذیرش مورد نظر پیدا نشد.', 'bad');
        redirect('customer-request-status.php');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        checkCsrf();

        $acceptedMain = isset($_POST['accepted_main']);
        $acceptedEstimate = isset($_POST['accepted_estimate']);
        $acceptedHold = isset($_POST['accepted_hold']);
        $acceptedPrivacy = isset($_POST['accepted_privacy']);
        $signature = trim((string)($_POST['typed_signature'] ?? ''));
        $nationalCode = trim((string)($_POST['signed_national_code'] ?? ''));

        if (!$acceptedMain || !$acceptedEstimate || !$acceptedHold || !$acceptedPrivacy) {
            flash('برای ثبت قرارداد، تایید تمام بندها الزامی است.', 'bad');
            redirect('customer-contract.php?request_id=' . $requestId);
        }
        if (!isPersianLettersAndSpace($signature)) {
            flash('نام و نام خانوادگی امضا کننده باید با حروف فارسی وارد شود.', 'bad');
            redirect('customer-contract.php?request_id=' . $requestId);
        }
        if (preg_match('/^[0-9]{10}$/', $nationalCode) !== 1) {
            flash('کد ملی امضا کننده باید ۱۰ رقم باشد.', 'bad');
            redirect('customer-contract.php?request_id=' . $requestId);
        }

        $pdo = getPdo();
        $contractCols = getTableColumns('portal_contract_confirmations');
        if ($contractCols) {
            $terms = [
                'accepted_main' => $acceptedMain,
                'accepted_estimate' => $acceptedEstimate,
                'accepted_hold' => $acceptedHold,
                'accepted_privacy' => $acceptedPrivacy,
            ];

            $payload = [];
            if (in_array('mobile', $contractCols, true)) {
                $payload['mobile'] = $mobile;
            }
            if (in_array('service_request_id', $contractCols, true)) {
                $payload['service_request_id'] = $requestId;
            }
            if (in_array('accepted_full_name', $contractCols, true)) {
                $payload['accepted_full_name'] = $signature;
            }
            if (in_array('is_accepted', $contractCols, true)) {
                $payload['is_accepted'] = 1;
            }
            if (in_array('ip_address', $contractCols, true)) {
                $payload['ip_address'] = currentIp();
            }
            if (in_array('accepted_terms_json', $contractCols, true)) {
                $payload['accepted_terms_json'] = json_encode($terms, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }
            if (in_array('contract_version', $contractCols, true)) {
                $payload['contract_version'] = 'MOGHARE360-ONLINE-V1';
            }
            if (in_array('accepted_national_code', $contractCols, true)) {
                $payload['accepted_national_code'] = $nationalCode;
            }
            if (in_array('accepted_mobile', $contractCols, true)) {
                $payload['accepted_mobile'] = $mobile;
            }
            if (in_array('service_request_code', $contractCols, true)) {
                $payload['service_request_code'] = (string)($request['jobcard_code'] ?? ('REQ-' . $requestId));
            }

            $insertCols = [];
            $insertVals = [];
            $params = [];
            foreach ($payload as $column => $value) {
                $insertCols[] = "`{$column}`";
                $insertVals[] = '?';
                $params[] = $value;
            }
            if (in_array('created_at', $contractCols, true)) {
                $insertCols[] = '`created_at`';
                $insertVals[] = 'NOW()';
            }
            if (in_array('accepted_at', $contractCols, true)) {
                $insertCols[] = '`accepted_at`';
                $insertVals[] = 'NOW()';
            }

            $insertSql = 'INSERT INTO portal_contract_confirmations (' . implode(', ', $insertCols) . ') VALUES (' . implode(', ', $insertVals) . ')';
            $insertStmt = $pdo->prepare($insertSql);
            $insertStmt->execute($params);
        }

        $requestCols = getTableColumns('portal_service_requests_staging');
        $setParts = [];
        $setParams = [];
        if (in_array('contract_confirmed', $requestCols, true)) {
            $setParts[] = '`contract_confirmed` = 1';
        }
        if (in_array('request_status', $requestCols, true)) {
            $setParts[] = "`request_status` = 'RECEPTION_REVIEW'";
        } elseif (in_array('status', $requestCols, true)) {
            $setParts[] = "`status` = 'RECEPTION_REVIEW'";
        }
        if (in_array('sync_status', $requestCols, true)) {
            $setParts[] = "`sync_status` = 'Pending'";
        }
        if (in_array('sync_error', $requestCols, true)) {
            $setParts[] = '`sync_error` = NULL';
        }
        if (in_array('updated_at', $requestCols, true)) {
            $setParts[] = '`updated_at` = NOW()';
        }
        if ($setParts) {
            $setParams[] = $requestId;
            $setParams[] = $mobile;
            $updateSql = 'UPDATE portal_service_requests_staging SET ' . implode(', ', $setParts) . ' WHERE id = ? AND mobile = ?';
            $updateStmt = $pdo->prepare($updateSql);
            $updateStmt->execute($setParams);
        }

        flash('قرارداد آنلاین تایید شد و پرونده شما به کارتابل پذیرش منتقل شد.');
        redirect('customer-request-status.php?request_id=' . $requestId);
    }

    renderHeader('قرارداد خدمات و پذیرش', 'تایید حقوقی مشتری');
    renderFlashes();
    ?>
    <main class="auth-wrap wide-auth">
      <section class="card flow-card">
        <h2>تایید قرارداد آنلاین</h2>
        <p class="muted">پس از تایید این قرارداد، پذیرش‌گر می‌تواند پرونده شما را وارد فرایند اجرایی کند.</p>
        <ol class="flow-steps">
          <li class="done">تکمیل پروفایل</li>
          <li class="done">ثبت پذیرش خودرو</li>
          <li class="active">تایید قرارداد</li>
          <li>پیگیری JobCard</li>
        </ol>
      </section>

      <form class="card form-card" method="post" action="customer-contract.php">
        <h2>قرارداد خدمات و تحویل خودرو</h2>
        <p class="muted">
          کد پرونده: <strong class="tracking-code"><?= e((string)($request['jobcard_code'] ?? ('REQ-' . $requestId))) ?></strong>
          | خودرو: <?= e((string)($request['vehicle_brand'] ?? '')) ?> <?= e((string)($request['vehicle_model'] ?? '')) ?>
        </p>
        <p class="contract-text">
          ۱) مشتری صحت اطلاعات خودرو و درخواست را تایید می‌کند.
          <br>۲) مجموعه مجاز به کارشناسی، تست و اعلام برآورد اولیه است.
          <br>۳) هر تغییر هزینه فقط پس از اطلاع و تایید مشتری اعمال می‌شود.
          <br>۴) خودرو بدون تسویه نهایی تحویل نمی‌شود مگر با مجوز مدیر مجموعه.
          <br>۵) Override فرایند فقط توسط مدیر دارای سطح دسترسی مجاز است.
        </p>

        <?= csrfField() ?>
        <input type="hidden" name="request_id" value="<?= e((string)$requestId) ?>">

        <label class="checkbox-line"><input type="checkbox" name="accepted_main" value="1"> متن قرارداد را مطالعه و تایید می‌کنم.</label>
        <label class="checkbox-line"><input type="checkbox" name="accepted_estimate" value="1"> می‌پذیرم افزایش برآورد بدون تایید مجدد من اجرا نشود.</label>
        <label class="checkbox-line"><input type="checkbox" name="accepted_hold" value="1"> می‌پذیرم تحویل خودرو منوط به تسویه نهایی یا مجوز مدیر است.</label>
        <label class="checkbox-line"><input type="checkbox" name="accepted_privacy" value="1"> با نگهداری سوابق پرونده خودرو در سامانه موافقم.</label>

        <label>نام و نام خانوادگی جهت امضا
          <input name="typed_signature" required placeholder="نام کامل فارسی">
        </label>

        <label>کد ملی امضا کننده
          <input class="national-code-field input-number" name="signed_national_code" inputmode="numeric" maxlength="10" required>
        </label>

        <label>شماره موبایل تاییدکننده
          <input class="mobile-field input-number" value="<?= e($mobile) ?>" readonly>
        </label>

        <div class="action-row">
          <button class="btn primary" type="submit">تایید نهایی قرارداد</button>
          <a class="btn ghost" href="customer-service-request.php">بازگشت</a>
          <a class="btn danger" href="customer-logout.php">خروج از حساب کاربری</a>
        </div>
      </form>
    </main>
    <?php
    renderFooter();
} catch (Throwable $e) {
    showErrorPage('خطا در نمایش قرارداد.', $e->getMessage());
}
